<?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper" id='app'>

  <!-- Navbar -->
  <?php echo $__env->make('inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php echo $__env->make('inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->

  
  <div class="content-wrapper">
    <v-app>
       <router-view></router-view>
       <vue-progress-bar></vue-progress-bar>
       <?php echo $__env->yieldContent('content'); ?>
    </v-app>
     
  </div>
  <!-- /.content-wrapper -->


<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\mortgase\resources\views/layouts/master.blade.php ENDPATH**/ ?>