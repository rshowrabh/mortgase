<?php $__env->startComponent('mail::message'); ?>
# Introduction

<p>Someone has invited you </p>

<?php $__env->startComponent('mail::button', ['url' => route('accept', $invite->token)]); ?>
Accept
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\mortgase\resources\views/emails/invite.blade.php ENDPATH**/ ?>