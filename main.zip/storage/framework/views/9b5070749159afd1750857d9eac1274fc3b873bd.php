<?php $__env->startSection('content'); ?>
   
    <question></question>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mortgase\resources\views/client/question.blade.php ENDPATH**/ ?>