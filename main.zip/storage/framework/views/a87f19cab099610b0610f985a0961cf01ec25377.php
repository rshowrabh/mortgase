<?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper" id='app'>

  <!-- Navbar -->
  <?php echo $__env->make('inc.client-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- /.navbar -->

 

  <!-- Content Wrapper. Contains page content -->

  
  <div class="content-wrapper">
    <v-app>
       <vue-progress-bar></vue-progress-bar>
       <?php echo $__env->yieldContent('content'); ?>
    </v-app>
     
  </div>
  <!-- /.content-wrapper -->


<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
  $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});


$.ajax({
    type: 'get',
    url: "api/get_agent_data",
    success: function (response) {
        const agent = response.data
        $('#logo').attr('src', '/storage/images/'+agent.logo )
        $('#logo').css('border-color', agent.color_system)
        $('#button1').css('border-color', agent.color_system)
        
        $("#button1").hover(function(){
  $(this).css('background-color', agent.color_system);
  }, function(){
  $(this).css("background-color", 'transparent');
});
    }
});
</script>
<?php /**PATH C:\xampp\htdocs\mortgase\resources\views/layouts/client.blade.php ENDPATH**/ ?>