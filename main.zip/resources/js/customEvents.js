//Setup our custom events in vue

let Fire = new Vue()
window.Fire = Fire;
