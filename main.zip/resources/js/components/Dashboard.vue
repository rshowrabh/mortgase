<template></template>

<script>
import ChartJs from "./../../../node_modules/admin-lte/plugins/chart.js/Chart.min.js";
import Init from "./../../js/plugins_init.js";
export default {
  mounted() {
    console.log("Component mounted.");
  },
};
</script>
